<?php

namespace Box\Spout\Common\Exception;

/**
 * Class SpoutException
 *
 * @package Box\Spout\Common\Exception
 * @abstract
 */
abstract class SpoutException extends \Exception
{
}
