== For Translators ==

We are migrating translations to translate.wordpress.org; the language files in this directory will be removed as soon as the languages are fully translated and available from translate.wordpress.org.

For details, see
http://contactform7.com/2016/01/08/translations-migrate-to-translate-wordpress-org/

We welcome your contribution to the collaborative translation project.

Thank you.
